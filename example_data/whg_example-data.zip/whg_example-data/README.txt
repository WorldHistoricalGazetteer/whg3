WHG example data files
2023-02-26


Linked Places format (JSON-LD based; GeoJSON-compatible)
	https://github.com/LinkedPasts/linked-places-format)
=======================================================
From HGIS de las Indias (https://www.hgis-indias.net/) dataset.
- lugares_20.jsonld: HGIS de las Indias settlements

LP-TSV format (delimited file formats)
	https://tinyurl.com/49d6zhks
======================================
- diamonds135.tsv : 135 sample records mainly from Indonesia
- croniken.tsv: 181 sample records from the Baltics and Poland
- template-places.tsv: 7 varied records from the template spreadsheet

Spreadsheet templates
=====================
Contain all valid columns + 7 sample records and format guide

- LP-TSV_template.xlsx
- LP-TSV_template.ods
	

